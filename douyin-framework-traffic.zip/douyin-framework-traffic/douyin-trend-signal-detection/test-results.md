# test-results — douyin-trend-signal-detection

## 首轮盲测（独立子代理，仅见 description）
- pos-1 ✓ / pos-2 ✓ / pos-3 ✓ / pos-4 ✓（判"边界:B"，接受）
- neg-1-sibling ✓（正确路由到 framework-first）/ neg-2-sibling ✓（正确路由到 transplant）
- neg-3 ✓
- edge-1 ✓（判"无"，与"声明超出范围"等价，接受）
- edge-2 ✗（判"无"，预期"边界可类比"）→ 根因：description 对非抖音平台一刀切排除，回炉改为"仅可类比参考，需声明限制"

## 修复后重测
- edge-2（b9 视频号三农）→ 边界:B ✓

**最终通过率: 9/9**
